package main;

import static org.junit.Assert.*;

import org.junit.Test;

public class HandTest {

	@Test
	public void testGetSum() {
		Hand h = new Hand();
		
		h.addCard(new Card(1, "Diamond"));
		h.addCard(new Card(1, "Heart"));
		assertEquals(12, h.getSum());
	}

}
