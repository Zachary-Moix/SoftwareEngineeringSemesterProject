package main;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

import main.Player;
import ocsf.server.*;
import main.DatabaseFile;
import main.GameData;

public class Server extends AbstractServer{

	private JTextArea log;
	private JLabel status;
	private DatabaseFile dbf;
	//a number of connections so that the server can easily identify which player sends messages
	private ConnectionToClient[] connections;
	private int numPlayers;
	//private Game[] games;
	Game g;
	
	public Server() {
		super(12345);
		dbf = new DatabaseFile();
		connections = new ConnectionToClient[100];
		numPlayers = 0;
		g = new Game();
		//games = new Game[20];
	}
	
	public Server(int port) {
		super(port);
		dbf = new DatabaseFile();
		connections = new ConnectionToClient[100];
		numPlayers = 0;
		g = new Game();
		//games = new Game[20];
	}
	
	public void setLog(JTextArea log) {
		this.log = log;
	}
	
	public JTextArea getLog() {
		return log;
	}
	
	public void setStatus(JLabel status) {
		this.status = status;
	}
	
	public JLabel getStatus() {
		return status;
	}

	@Override
	protected void handleMessageFromClient(Object arg0, ConnectionToClient arg1) {
		// TODO Auto-generated method stub
		
		
		
	}
	
	protected void listeningException(Throwable exception) {
		System.out.println("Listening Exception: " + exception);
		exception.printStackTrace();
	}
	
	protected void serverStarted() { 
		log.append("Server started.\n");
	}
	
	protected void serverStopped() { 
		log.append("Server stopped.\n");
	}
	
	protected void serverClosed() { 
		log.append("Server closed.\n");
	}
	
	protected void clientDisconnected(ConnectionToClient client) {
		
		numPlayers--;
	}
	
	protected void clientConnected(ConnectionToClient client)
	{
		
		try {
			if(gameHasOpening()) {
				Player player = new Player(client, numPlayers);
				client.sendToClient("GAME: 0");
				client.sendToClient("PLAYER: 0");
				numPlayers++;
				g.addPlayer(player);
			}
			else {
				client.sendToClient("ERROR: Game is full. Please wait...");
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
		
		
		/*int x = gameHasOpening();
		if(x == -1) {
			if(games.length < 20) {
				Game g = new Game();
				games[games.length] = g;
				Player player = new Player(client, numPlayers);
				connections[numPlayers] = client;
				numPlayers++;
				games[games.length].addPlayer(player);
				player.getConnectionToClient().sendToClient("GAME: " + 0 );
				player.getConnectionToClient().sendToClient("PLAYER: " 0);
				g.run();
			}
			else {
				client.sendToClient("ERROR: All games currently full, please wait");
			}
		}
		else {
			Player player = new Player(client, numPlayers);
			games[x].addPlayer(player);
			connections[numPlayers] = client;
			numPlayers++;
			player.getConnectionToClient().sendToClient("GAME: " + x);
			player.getConnectionToClient().sendToClient("Player: " + games[x].getNumPlayers());
		}*/
	}
	
	private boolean gameHasOpening() {
		
		return g.getNumPlayers() < 5;
		
		/*for(int i = 0; i < games.length; i++) {
			if(!(games[i].isFull())) {
				return i;
			}
		}
		return -1;*/
	}
	
}
